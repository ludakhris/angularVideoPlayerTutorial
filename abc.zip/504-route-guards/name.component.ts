import { Component } from '@angular/core';

@Component({
  selector: 'some-name',
  template: `
    <section class="card">
      <div class="card-content">
        <div class="card-title">Hello Bubba!</div>
        <p>This is another example component.</p>
      </div>
    </section>
  `
})
export class NameComponent {}
