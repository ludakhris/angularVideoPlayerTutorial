import { Component } from '@angular/core';

@Component({
  selector: 'app-email',
  templateUrl: './email-container.component.html'
})
export class EmailContainerComponent {}
