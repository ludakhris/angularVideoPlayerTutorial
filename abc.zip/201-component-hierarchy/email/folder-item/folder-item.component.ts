import { Component } from '@angular/core';

@Component({
  selector: 'folder-item',
  templateUrl: './folder-item.component.html'
})
export class FolderItemComponent {}
