# Workshop for this step

There is no important workshop for this step, but if you have added
any numerical or date data (data beyond what we provided in the
sample) you may wish to use the number or date pipe to format it.
