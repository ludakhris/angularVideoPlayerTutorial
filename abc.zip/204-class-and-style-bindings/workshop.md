# Workshop for this step

* Highlight a video when the user clicks (selects) it.
