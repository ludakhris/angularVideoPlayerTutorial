import { Component } from '@angular/core';
// import { Router, Event } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  // constructor(router: Router) {
  //   router.events.subscribe((event: Event) =>
  //     console.log('router event!', event));
  // }
}
